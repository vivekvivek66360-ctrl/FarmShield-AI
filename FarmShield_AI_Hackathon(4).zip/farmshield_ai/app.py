from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
import os
from dotenv import load_dotenv

load_dotenv()
app = Flask(__name__)
CORS(app)

try:
    from google import genai
    api_key = os.getenv('GEMINI_API_KEY')
    ai_client = genai.Client(api_key=api_key) if api_key else None
except Exception:
    ai_client = None


def clamp(n):
    return max(0, min(100, int(round(n))))


def risk_analysis(data):
    crop = str(data.get('crop', 'Rice'))
    location = str(data.get('location', 'Your farm'))
    temp = float(data.get('temperature', 30))
    rain = float(data.get('rainfall', 40))
    humidity = float(data.get('humidity', 65))
    soil = float(data.get('soil_moisture', 45))

    flood = clamp((rain - 50) * 1.4 + humidity * 0.22)
    heat = clamp((temp - 28) * 7 + (humidity - 65) * 0.15)
    drought = clamp((35 - soil) * 2.1 + max(0, temp - 30) * 2.4 - rain * 0.18)
    overall = clamp(max(flood, heat, drought) * 0.68 + (flood + heat + drought) / 3 * 0.32)

    def level(score):
        return 'High' if score >= 70 else 'Moderate' if score >= 40 else 'Low'

    risks = {'Flood / Waterlogging': flood, 'Heat stress': heat, 'Dry soil / drought': drought}
    highest = max(risks, key=risks.get)
    actions = []
    if flood >= 40:
        actions += ['Clear field drains and avoid blocking natural water flow.', 'Inspect low-lying areas and prepare a safe route for people and equipment.']
    if heat >= 40:
        actions += ['Check crops during early morning or evening to reduce heat exposure.', 'Monitor plants for wilting and consider irrigation timing based on crop needs.']
    if drought >= 40:
        actions += ['Check soil moisture at root depth before irrigation.', 'Prioritize water for vulnerable crop areas and reduce avoidable water loss.']
    if overall < 40:
        actions += ['Continue routine crop monitoring and recheck conditions if weather changes.']
    actions = list(dict.fromkeys(actions))[:5]

    report = {
        'location': location, 'crop': crop, 'overall': overall, 'overall_level': level(overall),
        'risks': [{'name': name, 'score': score, 'level': level(score)} for name, score in risks.items()],
        'primary_risk': highest, 'actions': actions,
        'conditions': {'temperature': temp, 'rainfall': rain, 'humidity': humidity, 'soil_moisture': soil},
        'mode': 'Rule-based demo analysis'
    }
    if ai_client:
        try:
            prompt = f"You are a cautious agricultural climate advisor. Based on this simulated/demo weather data, give 3 concise practical precautions, no unsupported certainty. Crop: {crop}; Location: {location}; temperature: {temp} C; rainfall: {rain} mm (demo input); humidity: {humidity}%; soil moisture: {soil}%. Risk scores: {risks}. Overall score: {overall}/100. Clearly state these are based on user-entered demo conditions, not a live forecast."
            result = ai_client.models.generate_content(model='gemini-2.5-flash', contents=prompt)
            if result and result.text:
                report['advisor'] = result.text
                report['mode'] = 'Gemini AI advisor + rule-based risk scores'
        except Exception as exc:
            print('Gemini unavailable; using fallback advisor:', exc)
    if not report.get('advisor'):
        report['advisor'] = f"For {crop} in {location}, your highest demo risk is {highest.lower()}. Use the precautions below as a starting point, and verify local forecasts and crop-specific guidance before taking action."
    return report


@app.get('/')
def home():
    return render_template('index.html')



@app.post('/api/analyze')
def analyze():
    try:
        data = request.get_json(force=True)
        report = risk_analysis(data)
        return jsonify(report)
    except (ValueError, TypeError) as exc:
        return jsonify({'error': 'Please enter valid numeric weather values.'}), 400



@app.get('/api/health')
def health():
    return jsonify({'status': 'ok', 'service': 'FarmShield AI'})



if __name__ == '__main__':
    app.run(host='127.0.0.1', port=5000, debug=True)
