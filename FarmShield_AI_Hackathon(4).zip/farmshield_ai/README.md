# FarmShield AI - IDEA FORGE Track 2 prototype

A climate-risk demo dashboard for agricultural resilience. It calculates heuristic flood/waterlogging, heat stress, and drought risk scores from manually entered demo conditions and provides precautionary recommendations.


## Run on Windows (VS Code terminal)
1. Install Python if needed.
2. Open this project folder in VS Code.
3. In the terminal run:
   `python -m pip install -r requirements.txt`
4. Optional: copy `.env.example` to `.env` and add a Gemini API key to enable generated advisor text. Risk analysis and fallback guidance work without a key.
5. Start the app:
   `python app.py`
6. Open `http://127.0.0.1:5000` in your browser.


## Demo notes
All climate inputs are manually entered demo values. The prototype does not fetch live weather data or provide official crop advisories. The scores are heuristic demo indicators only.
