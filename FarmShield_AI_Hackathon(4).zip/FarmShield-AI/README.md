# FarmShield AI 🌱
**AI Climate Risk & Farmer Resilience Assistant** — a hackathon prototype for Track 2: Climate, Resource Infrastructure & Global Supply Resilience.


FarmShield helps farmers explore potential climate risks using crop selection and manually entered weather conditions, then provides simple preventive suggestions.

## Prototype features
- Crop selection for Rice, Tomato, Wheat, Maize, Cotton, Potato and Millet
- Temperature and rainfall input
- Heat, heavy rainfall and dry-spell risk indicators
- Overall risk summary
- Practical farmer action plan
- Responsive dashboard for mobile and desktop

## Run locally
1. Install Python 3.10+.
2. In a terminal, enter the project folder.
3. Create and activate a virtual environment (optional but recommended):
   ```bash
   python -m venv .venv
   .venv\Scripts\activate
   ```
4. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
5. Run:
   ```bash
   python app.py
   ```
6. Open `http://127.0.0.1:5000` in your browser.

## Important limitation
This demo uses simple rule-based thresholds and the weather values entered by the user. It does **not** use live weather feeds, satellite imagery, or a trained AI model. Risk outputs are illustrative prototype estimates—not forecasts or professional agronomic advice.

## Built with
- Python / Flask
- HTML
- CSS
- JavaScript
