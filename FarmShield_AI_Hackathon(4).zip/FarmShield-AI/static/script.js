const form = document.getElementById('riskForm');
const emptyState = document.getElementById('emptyState');
const resultContent = document.getElementById('resultContent');
const loading = document.getElementById('loading');

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  emptyState.classList.add('hidden');
  resultContent.classList.add('hidden');
  loading.classList.remove('hidden');
  const payload = {
    crop: document.getElementById('crop').value,
    temperature: Number(document.getElementById('temperature').value),
    rainfall: Number(document.getElementById('rainfall').value)
  };
  try {
    const response = await fetch('/api/analyze', {
      method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(payload)
    });
    if (!response.ok) throw new Error('Could not analyze conditions. Please try again.');
    const data = await response.json();
    renderReport(data);
  } catch (error) {
    emptyState.classList.remove('hidden');
    emptyState.querySelector('h3').textContent = 'Something went wrong';
    emptyState.querySelector('p').textContent = error.message;
  } finally {
    loading.classList.add('hidden');
  }
});

function renderReport(data) {
  const banner = document.getElementById('riskBanner');
  banner.className = `risk-banner ${data.overall.toLowerCase()}`;
  document.getElementById('riskTitle').textContent = `${data.overall} risk`;
  document.getElementById('riskEmoji').textContent = data.overall === 'High' ? '⚠️' : data.overall === 'Moderate' ? '🟡' : '🟢';
  document.getElementById('summary').textContent = data.summary;
  document.getElementById('riskList').innerHTML = data.risks.map(r => `<div class="risk-item"><div class="risk-icon">${r.icon}</div><div class="risk-text"><strong>${r.name}</strong><small>${r.detail}</small></div><span class="level ${r.level.toLowerCase()}">${r.level}</span></div>`).join('');
  document.getElementById('recommendations').innerHTML = data.recommendations.map(r => `<li>${r}</li>`).join('');
  document.getElementById('note').textContent = data.note;
  resultContent.classList.remove('hidden');
}
