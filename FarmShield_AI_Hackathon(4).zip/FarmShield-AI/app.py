from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

CROP_THRESHOLDS = {
    "Rice": {"heat": 35, "rain_high": 180, "rain_low": 20},
    "Tomato": {"heat": 32, "rain_high": 120, "rain_low": 15},
    "Wheat": {"heat": 30, "rain_high": 100, "rain_low": 10},
    "Maize": {"heat": 34, "rain_high": 150, "rain_low": 20},
    "Cotton": {"heat": 38, "rain_high": 160, "rain_low": 15},
    "Potato": {"heat": 28, "rain_high": 100, "rain_low": 20},
    "Millet": {"heat": 38, "rain_high": 130, "rain_low": 10},
}


@app.route('/')
def home():
    return render_template('index.html')



@app.post('/api/analyze')
def analyze():
    data = request.get_json(force=True)
    crop = data.get('crop', 'Rice')
    temp = float(data.get('temperature', 0))
    rain = float(data.get('rainfall', 0))
    thresholds = CROP_THRESHOLDS.get(crop, CROP_THRESHOLDS['Rice'])

    risks = []
    recommendations = []
    score = 0

    if temp >= thresholds['heat']:
        risks.append({'name': 'Heat stress', 'level': 'High', 'icon': '☀️', 'detail': f'{temp:g}°C is above the suggested demo threshold for {crop}.'})
        recommendations += ['Provide irrigation during cooler hours if water is available.', 'Use mulch to reduce soil moisture loss.', 'Check plants for wilting or leaf scorching.']
        score += 2
    elif temp >= thresholds['heat'] - 3:
        risks.append({'name': 'Heat stress', 'level': 'Moderate', 'icon': '🌤️', 'detail': 'Temperature is approaching the demo heat threshold.'})
        recommendations += ['Monitor the crop during the hottest part of the day.', 'Keep soil moisture steady where possible.']
        score += 1
    else:
        risks.append({'name': 'Heat stress', 'level': 'Low', 'icon': '🌡️', 'detail': 'Temperature is below the demo heat threshold.'})

    if rain >= thresholds['rain_high']:
        risks.append({'name': 'Heavy rainfall / waterlogging', 'level': 'High', 'icon': '🌧️', 'detail': 'Rainfall is in the high range for this prototype.'})
        recommendations += ['Inspect field drainage and clear blocked channels.', 'Avoid entering waterlogged fields until conditions are safe.', 'Check plants for signs of fungal disease after rain.']
        score += 2
    elif rain >= thresholds['rain_high'] * 0.65:
        risks.append({'name': 'Heavy rainfall / waterlogging', 'level': 'Moderate', 'icon': '🌦️', 'detail': 'Rainfall is elevated; monitor drainage.'})
        recommendations += ['Check drainage outlets and watch for water pooling.']
        score += 1
    else:
        risks.append({'name': 'Heavy rainfall / waterlogging', 'level': 'Low', 'icon': '☁️', 'detail': 'Rainfall is below the demo heavy-rain threshold.'})

    if rain <= thresholds['rain_low'] and temp >= 28:
        risks.append({'name': 'Dry spell / drought stress', 'level': 'High', 'icon': '💧', 'detail': 'Low rainfall combined with warm conditions may increase water stress.'})
        recommendations += ['Check soil moisture before irrigating.', 'Prioritize water for sensitive crop stages.', 'Consider water-saving irrigation methods.']
        score += 2
    elif rain <= thresholds['rain_low']:
        risks.append({'name': 'Dry spell / drought stress', 'level': 'Moderate', 'icon': '💧', 'detail': 'Rainfall is low; monitor soil moisture.'})
        recommendations += ['Check soil moisture regularly and plan irrigation if needed.']
        score += 1
    else:
        risks.append({'name': 'Dry spell / drought stress', 'level': 'Low', 'icon': '💧', 'detail': 'Rainfall is not in the low range for this prototype.'})

    overall = 'Low'
    if score >= 4:
        overall = 'High'
    elif score >= 2:
        overall = 'Moderate'

    if not recommendations:
        recommendations = ['Continue regular crop monitoring.', 'Maintain your usual irrigation and field-care routine.', 'Recheck risk if weather conditions change.']
    recommendations = list(dict.fromkeys(recommendations))[:6]

    summary = {
        'High': f'{crop} may face multiple weather stresses. Take the precautions below and check your field conditions.',
        'Moderate': f'Some weather conditions may affect {crop}. Monitoring and preventive action can help.',
        'Low': f'No major risk is flagged by these inputs for {crop}. Continue regular field monitoring.'
    }[overall]

    return jsonify({'crop': crop, 'overall': overall, 'score': score, 'risks': risks, 'recommendations': recommendations, 'summary': summary,
                   'note': 'Prototype estimate using the values you entered—not a live weather forecast or agricultural diagnosis.'})


if __name__ == '__main__':
    app.run(debug=True)
